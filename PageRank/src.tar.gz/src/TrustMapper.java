import java.io.IOException;
import java.util.*;

import org.apache.hadoop.fs.Path;
import org.apache.hadoop.conf.*;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.util.*;


public class TrustMapper extends Mapper<IntWritable, Node, IntWritable, NodeOrDouble> {

    public void map(IntWritable key, Node value, Context context) throws IOException, InterruptedException {
        //pass the structure to the graph;
        context.getCounter(LossCounter.counter.SIZE).increment(1);
        context.write(key, new NodeOrDouble(value));
        if(value.outgoingSize() != 0) {
            double prank = value.getPageRank() / value.outgoingSize();
            Iterator<Integer> itr = value.iterator();
            while(itr.hasNext()) {
                int id = itr.next();
                context.write(new IntWritable(id), new NodeOrDouble(prank));
            }
        }
        //Handle the sink node;
        else {
            context.getCounter(
          LossCounter.counter.LEFTOVER).increment(
           (long)(Integer.MAX_VALUE * value.getPageRank()));
        }
    }
}
